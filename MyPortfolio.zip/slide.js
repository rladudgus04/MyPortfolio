window.onload = function(){
    $('.slick-container').slick({
        speed: 1000,
        fade: true,
        arrows: true
    });
}

